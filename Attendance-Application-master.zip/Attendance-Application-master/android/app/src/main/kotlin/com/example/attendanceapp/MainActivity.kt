package com.example.attendanceapp

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
