class BottomNavState{
  final int tabIndex;
  const BottomNavState({required this.tabIndex});
}

class BottomNavInitial extends BottomNavState{
  BottomNavInitial({required super.tabIndex});
}